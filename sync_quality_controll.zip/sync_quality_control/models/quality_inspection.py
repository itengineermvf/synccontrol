# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from datetime import datetime
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class QualityInspection(models.Model):
    _name = "quality.inspection"
    _description = "Quality Inspection"
    _inherit = ['mail.thread', 'barcodes.barcode_events_mixin']
    _rec_name = 'code'

    def _compute_show_lots_text(self):
        group_production_lot_enabled = self.user_has_groups('stock.group_production_lot')
        for inspection in self:
            inspection.show_lots_text = False
            if inspection.picking_id and group_production_lot_enabled and inspection.picking_id.picking_type_id.use_create_lots \
                    and not inspection.picking_id.picking_type_id.use_existing_lots:
                inspection.show_lots_text = True

    @api.depends('lot_name', 'employee_id', 'lot_id')
    def _compute_show_inspection_line(self):
        for inspection in self:
            inspection.show_inspection_line = False
            if (inspection.lot_name or inspection.lot_id) and inspection.employee_id:
                inspection.show_inspection_line = True

    code = fields.Char('Reference', copy=False, default=lambda self: _('New'),
                       readonly=True, required=True)
    alert_ids = fields.One2many('quality.control.alert', 'quality_inspection_id', string='Alerts')
    name = fields.Char('Name', required=False)
    point_id = fields.Many2one('quality.control.point', string='Control Point')
    quality_inspection_line_ids = fields.One2many('quality.inspection.line', 'quality_inspection_id',
                                                  string='Inspection Lines')
    product_id = fields.Many2one('product.product', 'Product',
                                 domain="[('product_tmpl_id', '=', product_tmpl_id)]", required=True)
    product_tmpl_id = fields.Many2one('product.template', 'Product Template', required=False,
                                      domain="[('type', 'in', ['consu', 'product'])]")
    picking_id = fields.Many2one('stock.picking', 'Operation')
    user_id = fields.Many2one('res.users', 'Responsible', track_visibility='onchange')
    team_id = fields.Many2one('quality.control.alert.team', 'Team', required=True)
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.user.company_id)
    note = fields.Html('Note', readonly=True)
    state = fields.Selection([('none', 'To do'), ('pass', 'Passed'), ('fail', 'Failed')],
                             string='Status', track_visibility='onchange', default='none', copy=False, tracking=True)
    lot_id = fields.Many2one('stock.production.lot', 'Lot')
    lot_name = fields.Char('Lot/Serial Number Name')
    product_tracking = fields.Selection(related='product_id.tracking')
    inspection_type = fields.Selection([('incoming', 'Incoming Inspection'), ('outgoing', 'Outgoing Inspection'),
                                        ('in_progress', 'In-progress Inspection'), ('final', 'Final Inspection')],
                                       string='Inspection Type', track_visibility='onchange', copy=False)
    purchase = fields.Char("Purchase", related="picking_id.group_id.name", store="True")
    show_lots_text = fields.Boolean(compute='_compute_show_lots_text', default=False)
    show_inspection_line = fields.Boolean(compute='_compute_show_inspection_line', default=False)
    employee_id = fields.Many2one('hr.employee', 'Staff ID')

    @api.onchange('product_tmpl_id')
    def onchange_product_tmpl_id(self):
        self.product_id = self.product_tmpl_id.product_variant_ids.ids and self.product_tmpl_id.product_variant_ids[0]

    @api.onchange('point_id')
    def onchange_point_id(self):
        self.quality_point_line_ids = False
        if self.point_id:
            self.team_id = self.point_id.team_id.id

    def on_barcode_scanned(self, barcode):
        """
        Handles barcode scanning events for quality inspection view
        :param barcode: scanned barcode
        """
        self.ensure_one()
        # Check Emplpyee Barcode
        employee_id = self.env['hr.employee'].search([
                                                ('barcode', '=', barcode),
                                                '|', ('company_id', '=', self.company_id.id),
                                                ('company_id', '=', False)], limit=1)
        if employee_id:
            self.employee_id = employee_id.id
            return

        # Check Lot Barcode
        if self.show_lots_text:
            self.lot_name = barcode
            return
        else:
            lot_id = self.env['stock.production.lot'].search([
                                                        ('name', '=', barcode),
                                                        ('product_id', '=', self.product_id.id),
                                                        '|', ('company_id', '=', self.company_id.id),
                                                        ('company_id', '=', False)], limit=1)
            if lot_id:
                self.lot_id = lot_id.id
                return

        return {'warning': {
            'title': _('Wrong barcode'),
            'message': _('The barcode "%(barcode)s" doesn\'t correspond to a proper any Staff or Lot/Serial number.') % {'barcode': barcode}
        }}

    def do_fail(self):
        self.ensure_one()
        self.state = 'fail'
        return self.redirect_on_next_inspection()

    def do_pass(self):
        self.ensure_one()
        self.state = 'pass'
        return self.redirect_on_next_inspection()

    @api.model
    def create(self, values):
        if 'code' not in values or values['code'] == _('New'):
            values['code'] = self.env['ir.sequence'].next_by_code('quality.inspection') or _('New')
        return super(QualityInspection, self).create(values)

    def get_lot_id(self):
        self.ensure_one()
        return self.env['stock.production.lot'].search([('product_id', '=', self.product_id.id),
                                                        ('name', '=', self.lot_name),
                                                        ('company_id', '=', self.company_id.id)], limit=1).id

    def redirect_on_next_inspection(self):
        inspection_ids = False
        if self._context.get('inspection_ids'):
            inspection_ids = self._context.get('inspection_ids')
            if inspection_ids:
                inspection_ids.remove(inspection_ids[0])
                if inspection_ids:
                    action = self.env.ref('sync_quality_control.quality_inspection_action_small').read()[0]
                    action['context'] = {'inspection_ids': inspection_ids}
                    action['res_id'] = inspection_ids[0]
                    return action
        return {'type': 'ir.actions.act_window_close'}

    def change_employee_or_lot(self):
        self.ensure_one()
        action = self.env.ref('sync_quality_control.quality_inspection_action_small').read()[0]
        self.write({
            'employee_id': False,
            'lot_id': False,
            'lot_name': False
        })
        action['context'] = dict(self.env.context)
        action['res_id'] = self.id
        return action


class QualityInspectionLine(models.Model):
    _name = "quality.inspection.line"
    _description = "Quality Inspection Line"
    _inherit = ['mail.thread']

    code = fields.Char('Reference', copy=False, default=lambda self: _('New'),
                       readonly=True, required=True)
    name = fields.Char('Name', required=False)
    test_type_id = fields.Many2one('quality.control.point.test.type', 'Test Type', required=True,
                                   default=lambda self: self.env['quality.control.point.test.type'].search([('test_type', '=', 'choice')]))
    test_type = fields.Selection(related='test_type_id.test_type', string='Select Test Type')
    quality_inspection_id = fields.Many2one('quality.inspection', required=False)
    product_id = fields.Many2one(
        'product.product', 'Product Variant',
        domain="[('product_tmpl_id', '=', product_tmpl_id)]")
    product_tmpl_id = fields.Many2one(
        'product.template', 'Product', required=True,
        domain="[('type', 'in', ['consu', 'product'])]")
    measure = fields.Float('Measure', default=0.0, digits='Quality', track_visibility='onchange')
    measure_success = fields.Selection([('none', 'No measure'), ('pass', 'Pass'), ('fail', 'Fail')],
                                       string="Measure Success", readonly=True, store=True)
    norm_unit = fields.Many2one('uom.uom', string='Unit of Measure', ondelete='set null', index=True)
    note = fields.Html('Note')
    sequence = fields.Integer('Sequence', default=10)
    state = fields.Selection([('none', 'To do'), ('pass', 'Passed'), ('fail', 'Failed')],
                             string='Status', track_visibility='onchange', default='none', copy=False)
    picture = fields.Binary(string="Image")
    control_date = fields.Datetime('Control Date', track_visibility='onchange')
    failure_message = fields.Html('Failure Message')
    warning_message = fields.Text('Warning Message')
    norm = fields.Float('Norm', digits='Quality')
    norm_text = fields.Text('Text')
    tolerance_min = fields.Float('Min Tolerance', digits='Quality')
    tolerance_max = fields.Float('Max Tolerance', digits='Quality')
    product_tracking = fields.Selection(related='product_id.tracking')
    lot_id = fields.Many2one('stock.production.lot', 'Lot', related="quality_inspection_id.lot_id", store=True)
    lot_name = fields.Char('Lot/Serial Number Name', related="quality_inspection_id.lot_name", store=True)
    inspection_state = fields.Selection(related='quality_inspection_id.state', string='Inspection State')
    control_point_line_id = fields.Many2one('quality.control.point.line', ondelete='cascade')
    show_lots_text = fields.Boolean(related='quality_inspection_id.show_lots_text', default=False)
    move_line_id = fields.Many2one('stock.move.line', 'Move Line')
    control_point_line_checkboxs_ids = fields.Many2many('quality.control.point.line.checkboxs', relation='control_point_line_checkboxs_rel',
                                                domain="[('control_point_line_id', '=', control_point_line_id)]", string="QCP Checklist")

    @api.onchange('lot_name', 'lot_id')
    def onchange_serial_number(self):
        """
            Onchange method for lot id and lot name and check it is correct or not
        """
        res = {}
        context = dict(self.env.context or {})
        if self.product_id.tracking != 'none' and self.quality_inspection_id and self.quality_inspection_id.point_id.detailed_quality_inspection and \
                self.quality_inspection_id and context.get('picking_id'):
            message = None
            picking_id = self.env['stock.picking'].browse(context['picking_id'])
            if self.lot_id and not(any(picking_id.move_line_ids_without_package.filtered(lambda m: m.lot_id.id == self.lot_id.id and m.product_id.id == self.product_id.id))):
                message = _('Please select correct the lot number. It does not match with Picking Operation.')
            if self.lot_name and not(any(picking_id.move_line_ids_without_package.filtered(lambda m: m.lot_name == self.lot_name and m.product_id.id == self.product_id.id))):
                message = _('Please enter correct the lot number. It does not match with Picking Operation.')
            if message:
                res['warning'] = {'title': _('Warning'), 'message': message}
        return res

    def check_lot_serial_number(self):
        context = dict(self.env.context or {})
        if self.product_id.tracking != 'none' and self.quality_inspection_id and self.quality_inspection_id.point_id.detailed_quality_inspection and \
                self.quality_inspection_id and context.get('picking_id'):
            picking_id = self.env['stock.picking'].browse(context['picking_id'])
            if self.lot_id and not(any(picking_id.move_line_ids_without_package.filtered(lambda m: m.lot_id.id == self.lot_id.id and m.product_id.id == self.product_id.id))):
                raise ValidationError(_('Please select correct the lot number. It does not match with Picking Operation.'))
            if self.lot_name and not(any(picking_id.move_line_ids_without_package.filtered(lambda m: m.lot_name == self.lot_name and m.product_id.id == self.product_id.id))):
                raise ValidationError(_('Please enter correct the lot number. It does not match with Picking Operation.'))

    def _get_quality_alert_values(self):
        self.ensure_one()
        return {
            'product_id': self.product_id.id,
            'product_tmpl_id': self.product_id.product_tmpl_id.id,
            'quality_inspection_id': self.quality_inspection_id.id,
            'quality_inspection_line_id': self.id,
            'lot_id': self.lot_id.id,
            'lot_name': self.lot_name,
            'user_id': self.control_point_line_id.quality_control_point_id.team_id.user_id.id,
            'picking_id': self.quality_inspection_id.picking_id.id,
            'reason_ids': self.control_point_line_id.quality_control_point_id.reason_ids.ids,
            'company_id': self.quality_inspection_id.company_id.id
        }

    def generate_quality_alert(self):
        self.ensure_one()
        quality_control_point_id = self.control_point_line_id and self.control_point_line_id.quality_control_point_id
        if quality_control_point_id and quality_control_point_id.automatic_generate_quality_alert:
            quality_alert_vals = self._get_quality_alert_values()
            quality_alert_id = self.env['quality.control.alert'].create(quality_alert_vals)
            quality_alert_id.action_send_mail()
        return True

    def do_alert(self):
        self.ensure_one()
        action = self.env.ref('sync_quality_control.quality_control_alert_action_small').read()[0]
        action['context'] = {
            'default_product_id': self.product_id.id,
            'default_product_tmpl_id': self.product_id.product_tmpl_id.id,
            'default_quality_inspection_id': self.quality_inspection_id.id,
            'default_quality_inspection_line_id': self.id,
            'default_lot_id': self.lot_id.id,
            'default_lot_name': self.lot_name,
            'default_picking_id': self.quality_inspection_id.picking_id.id,
        }
        return action

    def do_text(self):
        self.ensure_one()
        self.check_lot_serial_number()
        if self.control_point_line_id.match_case_sensitive:
            if self.control_point_line_id.norm_text == self.norm_text:
                self.write({'state': 'pass', 'control_date': datetime.now(), 'norm_text': self.norm_text})
            else:
                self.write({'state': 'fail', 'control_date': datetime.now(), 'norm_text': self.norm_text})
                self.generate_quality_alert()
        else:
            if self.control_point_line_id.norm_text == self.norm_text.upper() or self.control_point_line_id.norm_text == self.norm_text.lower() or self.control_point_line_id.norm_text == self.norm_text:
                self.write({'state': 'pass', 'control_date': datetime.now(), 'norm_text': self.norm_text})
            else:
                self.write({'state': 'fail', 'control_date': datetime.now(), 'norm_text': self.norm_text})
                self.generate_quality_alert()

    @api.model
    def create(self, values):
        if 'code' not in values or values['code'] == _('New'):
            values['code'] = self.env['ir.sequence'].next_by_code('quality.inspection.line') or _('New')
        return super(QualityInspectionLine, self).create(values)

    def do_measure(self, is_multi=False):
        self.ensure_one()
        self.check_lot_serial_number()
        if self.tolerance_min == 0.00 and self.tolerance_max == 0.00 and self.measure != self.norm:
            self.write({'measure_success': 'fail',
                        'warning_message': _('You measured %.2f %s and it should be same as %.2f %s.') %
                                           (self.measure, self.norm_unit.name, self.norm, self.norm_unit.name)
                        })
            return self.do_fail()
        elif self.measure != self.norm and (self.measure < self.tolerance_min or self.measure > self.tolerance_max):
            self.write({'measure_success': 'fail',
                        'warning_message': _('You measured %.2f %s and it should be between %.2f and %.2f %s.') %
                                           (self.measure, self.norm_unit.name, self.tolerance_min,
                                            self.tolerance_max, self.norm_unit.name)
                        })
            return self.do_fail()
        else:
            self.write({'measure_success': 'pass'})
            return self.do_pass(is_multi=True)

    def do_fail(self):
        self.ensure_one()
        if self.test_type == 'image' and not self.picture:
            raise ValidationError(_("Please self image first."))
        self.check_lot_serial_number()
        self.write({'state': 'fail', 'control_date': datetime.now()})
        self.generate_quality_alert()
        return self.redirect_on_inspection()

    def redirect_on_inspection(self):
        self.ensure_one()
        action = self.env.ref('sync_quality_control.quality_inspection_action_small').read()[0]
        action['context'] = dict(self.env.context)
        action['res_id'] = self.quality_inspection_id.id
        return action

    def do_pass(self, is_multi=False):
        self.ensure_one()
        if self.control_point_line_id.is_checklist_editable and self.control_point_line_id.required_all_checklist and\
            self.control_point_line_id.quality_control_point_line_checkboxs_id and\
            self.control_point_line_checkboxs_ids != self.control_point_line_id.quality_control_point_line_checkboxs_id:
            raise ValidationError(_("You must need to select all checklist for pass this checkpoint."))
        if self.test_type == 'image' and not self.picture:
            raise ValidationError(_("Please self image first."))
        if self.test_type == 'text' and not self.norm_text:
            raise ValidationError(_("Please enter text first."))
        self.check_lot_serial_number()
        if self.test_type in ['choice', 'image'] or is_multi:
            self.write({'state': 'pass',
                        'control_date': datetime.now()})
        if not is_multi and self.test_type == 'measure':
            self.do_measure()
        elif not is_multi and self.test_type == 'text':
            self.do_text()
        return self.redirect_on_inspection()
