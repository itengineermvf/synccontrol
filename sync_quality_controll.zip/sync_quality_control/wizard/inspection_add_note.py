# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, fields, api


class InspectionAddNotes(models.TransientModel):
    _name = "inspection.add.notes"
    _description = "Inspection Add Notes"

    @api.model
    def default_get(self, fields):
        rec = super(InspectionAddNotes, self).default_get(fields)
        context = dict(self.env.context) or {}
        if context.get('active_model') == 'quality.inspection' and context.get('active_id'):
            inspection_id = self.env['quality.inspection'].browse(context['active_id'])
            rec.update({
                'inspection_id': inspection_id.id,
                'note': inspection_id.note
            })
        return rec

    note = fields.Html('Note')
    inspection_id = fields.Many2one('quality.inspection', string='Inspection')

    def add_notes(self):
        self.ensure_one()
        if self.inspection_id and self.note:
            self.inspection_id.note = self.note
        return True
